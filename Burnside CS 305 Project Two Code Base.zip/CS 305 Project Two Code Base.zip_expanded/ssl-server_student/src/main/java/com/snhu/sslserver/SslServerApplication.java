package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.security.MessageDigest;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class CheckSumController {
    @RequestMapping("/hash")
    public String getCheckSum() {
        // Set data variable to "Hello Jerimey Burnside"
        String data = "Hello Jerimey Burnside";
        
        // Calculate checksum using SHA-256 algorithm and return it as a string
        String checksum = calculateChecksum(data);
        
        // Return HTML response with data, name of algorithm used, and checksum value
        return "<p>data: " + data + "</p><p>Name of Algorithm Used: CheckSum </p><p>Checksum Value: " + checksum + "</p>";
    }
    
    // Method to calculate SHA-256 digest for a given string and return the hexadecimal representation of the hash
    private String calculateChecksum(String data) {
        try {
            // Create a SHA-256 digest using MessageDigest class
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            
            // Convert checksum to byte array and return it as hexadecimal string
            byte[] hashBytes = digest.digest(data.getBytes());
            return bytesToHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    
    // Method to convert a byte array to hexadecimal string
    private String bytesToHex(byte[] bytes){
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}